#common functions on list objects:
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
'''
1. len()
2. max()
3. min()
4. sorted()
5. sorted(L,reverse=True)
6. sum()
'''

L=[1,5,9,6,10]

print('length: ',len(L))#5
print('Max: ',max(L))#10
print('Min: ',min(L))#1
print('sorted: ',sorted(L))#[1,5,6,9,10]
print('sorted(Reverse ): ',sorted(L,reverse=True))# [10,9,6,5,1]
print('Sum: ',sum(L))#31

print(L)#[1,5,9,6,10]


