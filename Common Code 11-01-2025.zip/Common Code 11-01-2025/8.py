#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)
#4. remove(obj)
#5. pop()/pop(index)
#6. clear()
#7. index(obj)

L1=[10,20,30,40,50]

print(L1.index(40))#3
print(L1.index(10))#0
