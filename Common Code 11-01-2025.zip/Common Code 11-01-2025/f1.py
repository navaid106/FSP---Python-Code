def checkSym(text):
    if text.isalnum():
        return False
    else:
        return True



text1='aabbcc112233*&^'

result1 = checkSym(text1)#calling or invoking function

print(result1)#True

text2='asdfklas1232'

result2=checkSym(text2)
print(result2)#False


text3='aabbcc'

result3=checkSym(text3)
print(result3)#False

