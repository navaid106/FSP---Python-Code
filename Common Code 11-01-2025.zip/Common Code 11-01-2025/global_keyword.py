a=100 #Global variable

def fun1():
    a=500 #Local variable
    print(a)

def fun2():
    global a
    a=90000
    print(a)




fun2() #90000
fun1() #500

print(a)#90000

    
    
