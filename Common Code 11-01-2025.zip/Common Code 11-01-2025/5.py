#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)
#4. remove(obj)

L1=[10,20,30,30,30,40,30]

L1.remove(30)


print(L1)#[10,20,40]
