def fun(a:int,b:int): #a funtion with hint parameters
    res=a+b
    
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')
    print('I am inside the function')

    print('before return')
    return res
    print('after return')


a=fun(10,20)   #at the time of invoking it required two arguments/paraments/inputs

print(f'Addition is: {a}')
