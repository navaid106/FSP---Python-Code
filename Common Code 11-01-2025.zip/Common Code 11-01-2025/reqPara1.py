def fun(a,b):
    print(a)
    print(b)


fun(100,200)#calling or invoking
