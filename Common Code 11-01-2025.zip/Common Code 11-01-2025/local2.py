def fun1():
    x=100 #local variable

    print(f'{x} from fun1')

def fun2():
    x=200 #local variable
    print(f'{x} from fun2')


#calling function
fun1() #100 from fun1
fun2() #200 from fun2
fun1() #100 from fun1
