def filterStr(text:str) -> str:
    evenStr=''
    oddStr=''
    #check indexes
    for index in range(len(text)):#0 
        if index%2 == 0:
            evenStr+=text[index]
        else:
            oddStr+=text[index]

    return evenStr+'---'+oddStr



text='abcdefgh' #8

r1=filterStr(text)#calling or invoking function
print(r1)#aceg---bdfh
