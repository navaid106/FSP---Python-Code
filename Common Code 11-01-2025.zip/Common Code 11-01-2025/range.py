#List comprehension
'''
L1=[nobita for nobita in range(1,101,1) if nobita%2==0]
print(L1)

'''

L1=[]#1 2 3 4 5
Odd=[]
Even=[]
for i in range(1,101,1):#1 2 3 4 5
    if i%2==0:
        Even.append(i)
    else:
        Odd.append(i)



print('Odd List: ',Odd)
print('*'*77)
print()#new line or \n
print()
print()
print('Even List: ',Even)
   
    
