#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)
#4. remove(obj)
#5. pop()/pop(index)
#6. clear()
#7. index(obj)
#8. count(obj)
#9. reverse()
#10. sort()

L1=[10,20,15,12,11,5]

L1.sort()
print(L1)
