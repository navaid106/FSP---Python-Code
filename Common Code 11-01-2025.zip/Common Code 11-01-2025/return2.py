def fun():
    n1=10
    n2=20
    n3=30
    return n1 #consider
    return n2 #ignore
    return n3 #ingore

a=fun()#10
b=fun()#10
c=fun()#10

print(a)#10
print(b)#10
print(c)#10
