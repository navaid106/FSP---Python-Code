def allDigits(text:str)-> bool:
    if text.isdigit():
        return True
    else:
        return False


text1='1234'

r1=allDigits(text1)#calling or invoking

print(r1)#True

print(allDigits('123aa'))#False


