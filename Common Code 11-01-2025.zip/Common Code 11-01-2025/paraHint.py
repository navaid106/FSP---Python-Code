def fun(a:int,b:int):
    print(a*b)


fun(10,20)
fun(10.5,30.5)
