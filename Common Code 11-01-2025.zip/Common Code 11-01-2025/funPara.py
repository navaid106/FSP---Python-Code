def add(): #a function without parameters
    n1=10#local variable
    n2=20#local variable

    print(n1+n2)

def add2(n1,n2): #a functoin with parameters
    print(n1+n2)

add()#calling to add() function

add2(10,50)#can't call add2() function without giving inputs

a=100
b=200

add2(a,b)

num1=int(input('Enter num1: '))
num2=int(input('Enter num2: '))

add2(num1,num2)
    
