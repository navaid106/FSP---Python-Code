def fun(*num):
    largest = num[0]#10

    for index in range(len(num)):
        if num[index] > largest:
            largest=num[index] #each time re-assigning value in largest..

    return largest


r1=fun(10,1000)
print('Max: ',r1)



