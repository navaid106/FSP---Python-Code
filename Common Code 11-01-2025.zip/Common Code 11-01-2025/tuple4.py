#tuple with mathametical operations
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#1. + it'll do concatenation
#2. * repeat tuple object.


T1=(10,20,30)
T2=(40,50)

print(T1+T2)
print(T2*3)
