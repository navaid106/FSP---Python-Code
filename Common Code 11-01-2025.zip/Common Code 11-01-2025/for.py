#for: is used to repeat values or statement

#stop:11--> 1 2 3 4 5 6 7 8 9 10

for i in range(1,11,1):#1 2 3
    if i%2==0:
        print(i,'Nasar')
    else:
        print(i,'Python')

print('Bye!')


#for: is a keyword
# i: is a variable
# in: membership operator
# range(start,stop,step): is a datatype.

