def factorial(num:int):
    #logic for fact

    return fact


result=factorial(5)

print(result)#Factorial of 5 is : 120
