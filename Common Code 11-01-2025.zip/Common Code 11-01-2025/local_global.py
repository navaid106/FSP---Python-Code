x=100 #Global variable

def fun1():
    y=200 #Local variable

    print(f'Global variable: {x}')#100
    print(f'Local variable: {y}')#200

def fun2():
    z=300 #Local variable
    x=500 #Local variable

    print(f'Local variable: {z}')#300
    print(f'Local variable: {x}')#500

#calling function

fun1()
fun2()

print(f'Original X value: {x}')#100
