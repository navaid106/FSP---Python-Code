#tuple data structure
#~~~~~~~~~~~~~~~~~~~~~

#Creation of tuple objects
#~~~~~~~~~~~~~~~~~~~~~~~~~~~

#1. using ()
#2. tuple()
#3. eval()


L1=[10,20,30]
S="Hello"
T1=tuple(L1)
T2=tuple(S)

print(T1)
print(type(T1))

print(T2)
print(type(T2))
