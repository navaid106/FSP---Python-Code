#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)
#4. remove(obj)
#5. pop()/pop(index)

L1=[10,20,30,40]
#    0  1  2  3

L1.pop(1)

print(L1)#[10,30,40]
