'''
Calculator program
----------------------
1. Addition
2. Multiplicatino
3. Division

'''

def addition():
    print('Welcome to addition..')
    num1=int(input('Enter num1: '))
    num2=int(input('Enter num2: '))

    add=num1+num2

    print(f'Addition is: {add}')

def mult():
    print('Welcome to multiplication function...')
    num1=int(input('Enter num1: '))
    num2=int(input('Enter num2: '))

    mult=num1*num2

    print(f'Multiplication is: {mult}')

def division():
    print('Welcome to Division function...')
    num1=int(input('Enter num1: '))
    num2=int(input('Enter num2: '))

    div=num1*num2

    print(f'Multiplication is: {m}')


def error():
    print('Invalid choice')

print('*'*66)
print('1. Addition')
print('2. Multiplication')
print('3. Division')
print('*'*60)

ch=int(input('Enter your choice: '))#1

if ch == 1:
    addition()

elif ch == 2:
    mult()

elif ch == 3:
    division()

else:
    error()


