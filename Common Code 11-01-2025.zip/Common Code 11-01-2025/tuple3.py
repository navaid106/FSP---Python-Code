#Creation of tuple objects
#~~~~~~~~~~~~~~~~~~~~~~~~~~~

#1. using ()
#2. tuple()
#3. eval()


T1=eval(input('Enter data: '))

print(T1)
print(type(T1))
