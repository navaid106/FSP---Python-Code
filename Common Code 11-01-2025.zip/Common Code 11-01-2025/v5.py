def fun(*v):
    print(v)


fun()#calling or invoking....
