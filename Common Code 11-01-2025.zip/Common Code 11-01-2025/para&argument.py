def fun(para1,para2):
    print(para1)
    print(para2)


argu1=200
agru2=400

fun(argu1,agru2)
