text='hellolkajsdfkaljsdfnalskdfa'

f={}

#count char

for char in text:
    f[char] = 1 + f.get(char,0)

print(f)




