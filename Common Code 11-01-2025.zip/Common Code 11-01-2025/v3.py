#Add all the aguments are return sum
#note: only add digits type of values.

def sum(*a):
    add = 0
    for i in a:#
        if str(i).isdigit():
            add += int(i)
    return add


print(sum(1,2,3,4,'8','a'))
