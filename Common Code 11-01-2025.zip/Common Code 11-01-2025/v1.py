def fun(text='Empty text'): #a function is having required parameter
    print(text) #Empty text.


text='hello'
fun(text)#required argument passed successfully...

fun()#it shouldn't give any kind of error.
