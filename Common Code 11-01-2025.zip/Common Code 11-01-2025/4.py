#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)

L1=[1,2,3,4,5]

L2=['a','b','c']

L1.extend(L2)

print(L1)

