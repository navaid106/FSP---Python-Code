'''
[1,2,3,4,5,6,7,8,9,10]
show only even elements
[2, 4, 6, 8, 10]
'''
x=1
y=1
z=1
n=3
L1 = [[i,j,k] for i in range(x) for j in range(y) for k in range(z) if i+j+k!=n]
    
    
print(L1)









    
