num1=100 #Global variable
num2=20 #Global variable


def add():
    print(f'Sum of {num1} and {num2}: {num1+num2}')

def sub():
    print(f'Diff of {num1} and {num2}: {num1-num2}')


#calling function

add()
sub()
