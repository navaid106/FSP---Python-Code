#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)

L1=[1,2,3,4,5]
#   0 1 2 3 4

L1.insert(2,999)

print(L1)#[1,2,999,3,4,5]


