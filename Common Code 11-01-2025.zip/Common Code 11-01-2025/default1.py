def fun(num=0): #optional parameter
    print(num)


def fun1(num): #required parameter
    print(num)


fun()#calling or invoking function
fun(100)

fun1(10)
fun1(20)
