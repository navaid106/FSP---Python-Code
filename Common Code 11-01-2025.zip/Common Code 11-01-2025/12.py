#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj): add item in last
#2. insert(index,obj): based on index, it can insert element
#3. extend(iterable): it can add more than one element or a iterable in a list.
#4. remove(obj): remove an item from the list from starting position
#5. pop()# remove last element
#   pop(index): remove element based on index.
#6. clear(): delete all the elements from the list
#7. index(obj): returns index value of given element
#8. count(obj): counts the duplicates elements in list.
#9. reverse(): it can reverse a list
#10. sort(): it sort the element from min to max order.
#11. sort(reverse=True): it's sort the element from max to min order.


L1=[10,11,7,30,20]

L1.sort(reverse=True)

print(L1)
