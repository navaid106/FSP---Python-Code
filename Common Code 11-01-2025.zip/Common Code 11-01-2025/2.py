#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)

L=[1,2,3,4]

L.append(50)#modification

print(L)#[1,2,3,4,50]

