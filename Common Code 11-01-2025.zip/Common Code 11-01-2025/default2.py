def drawLine(ch='*',length=40): #option parameters
    for index in range(length):
        print(ch,end='')

    print()#empty print for new line


drawLine()
drawLine('~',10)
drawLine('~',20)
drawLine('~',30)
drawLine('~',40)
drawLine('~',50)
drawLine()




