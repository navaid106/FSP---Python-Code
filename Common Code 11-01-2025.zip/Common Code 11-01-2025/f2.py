def checkDigit(text:str):
    if text.isalpha():
        return False
    else:
        return True


text1='abc1234'
res1=checkDigit(text1)#calling or invoking

print(res1)#True

print(checkDigit('aabbcc'))#False
print(checkDigit('11aabb22'))#True
