def fun1(*a):#variable length parameter
    print('inside function')
    print(type(a))
    print(a)
    print(a[0])

fun1(10,20,30,40,50,60,70)
fun1('hello','world!',10,20)
fun1(10)
fun1(40,20)
