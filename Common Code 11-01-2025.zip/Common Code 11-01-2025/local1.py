def fun():
    n1=10 #local variable -1
    n2=20 #local variable -2

    print(n1)
    print(n2)


fun()#calling function
