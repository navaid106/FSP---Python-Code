def checkString(text:str)->bool:
    return text.isalpha()


text='abc123'
r1=checkString(text)#calling or invoking with required argument.
print(r1)#False

text1='abc'
r2=checkString(text1)

print(r2)#True


