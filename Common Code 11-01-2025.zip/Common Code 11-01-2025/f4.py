def addDigit(text:str) -> int:
    add=0
    for char in text:
        if char.isdigit():
            add+=int(char)

    return add
            
            



text='123ab981726394618lashjafsdfanjkasdd87342c1122'

r1=addDigit(text)#calling or invoking
print(f'Addition is: {r1}')#12
    
