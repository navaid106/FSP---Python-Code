#Write a function which return true if element is repeated
#else return false.


def checkRepeat(L1):
    S1 = set()# 1 2 3 4

    for i in L1:#1 2 3 4 1
        if i in S1:#False
            return True
        S1.add(i)
    return False
        


print(checkRepeat([1,2,3,4]))




