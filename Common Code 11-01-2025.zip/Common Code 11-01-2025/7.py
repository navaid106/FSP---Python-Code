#List specific methods
#~~~~~~~~~~~~~~~~~~~~~~
#1. append(obj)
#2. insert(index,obj)
#3. extend(iterable)
#4. remove(obj)
#5. pop()/pop(index)
#6. clear()

L1=[10,20,30,40]

print(L1)#[10,20,30,40]
L1.clear()

print(L1)#[]
