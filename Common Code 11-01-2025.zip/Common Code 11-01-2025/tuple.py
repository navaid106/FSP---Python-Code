'''
tuple data structure
~~~~~~~~~~~~~~~~~~~~~
1. it is a group of object.
2. it is represeted by using ().
3. it allows heterogeneous object.
4. it allows indexing.
5. it supports both +ve and -ve indexing.
6. Slicing is allowed.
#[1,2,3,4,5]----> [2,3,4]

7. insertion order is preserved.
8. duplicates are allowed.
9. it is not growable in natuer. (immutable: can't add/remove/update)
10. it is immutable i.e. modifications are not allowed.
'''

T=(10,20,30,True,False,2+5j,"abc")

print(T)#()
print(type(T))#<class tuple>
