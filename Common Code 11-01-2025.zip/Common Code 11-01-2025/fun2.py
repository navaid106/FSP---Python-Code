def fun(n):
    print('This is fun1')
    print(n)



fun(10)#correct
fun(111111)#correct
